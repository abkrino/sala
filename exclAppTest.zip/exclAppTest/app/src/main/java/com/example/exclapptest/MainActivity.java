package com.example.exclapptest;

import android.Manifest;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import com.getkeepsafe.taptargetview.TapTarget;
import com.getkeepsafe.taptargetview.TapTargetView;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    // Declare variables
    ArrayList<HashMap> FilePathStrings1;
    private String[] FileNameStrings;


    Button btnUpDirectory, btnSDCard;

    ArrayList<String> pathHistory;
    String lastDirectory;
    int count = 0;

    ArrayList<XYValue> uploadData;

    ListView lvInternalStorage;


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch(requestCode){
            case 10:
                if(resultCode==RESULT_OK){
                    String path=data.getData().getPath();
                    readExcelData(path);
                }
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lvInternalStorage = (ListView) findViewById(R.id.lvInternalStorage);
        btnUpDirectory = (Button) findViewById(R.id.btnUpDirectory);
        btnSDCard = (Button) findViewById(R.id.btnViewSDCard);
        uploadData = new ArrayList<>();
        FilePathStrings1 = new ArrayList<>();
        //need to check the permissions

        checkFilePermissions();

        TapTargetView.showFor(this, TapTarget.forView(findViewById(R.id.btnViewSDCard),"زرار الرفع","دوس هنا علشان ترفع القائمة"));
        lvInternalStorage.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent myFileIntent = new Intent(Intent.ACTION_GET_CONTENT);
                myFileIntent.setType("*/*");
                startActivityForResult(myFileIntent, 10);
//                lastDirectory = pathHistory.get(count);
                    //Execute method for reading the excel data.

                   checkInternalStorage();
            }
        });


        //Goes up one directory level
        btnUpDirectory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (count == 0) {
                    Log.d(TAG, "btnUpDirectory: You have reached the highest level directory.");
                } else {
                    pathHistory.remove(count);
                    count--;
                    checkInternalStorage();
                    Log.d(TAG, "btnUpDirectory: " + pathHistory.get(count));
                }
            }
        });

        //Opens the SDCard or phone memory
        btnSDCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count = 0;
                pathHistory = new ArrayList<String>();
                pathHistory.add(count, System.getenv("EXTERNAL_STORAGE"));
                Log.d(TAG, "btnSDCard: " + pathHistory.get(count));
                checkInternalStorage();
            }
        });

    }

    /**
     * reads the excel file columns then rows. Stores data as ExcelUploadData object
     *
     * @return
     */
    private void readExcelData(String filePath) {
        Log.d(TAG, "readExcelData: Reading Excel File.");

        //decarle input file
        File inputFile = new File(filePath);

        try {
            InputStream inputStream = new FileInputStream(inputFile);
            XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
            XSSFSheet sheet = workbook.getSheetAt(0);
            int rowsCount = sheet.getPhysicalNumberOfRows();
            FormulaEvaluator formulaEvaluator = workbook.getCreationHelper().createFormulaEvaluator();
            StringBuilder sb = new StringBuilder();

            //outter loop, loops through rows
            for (int r = 1; r < rowsCount; r++) {
                Row row = sheet.getRow(r);
                int cellsCount = row.getPhysicalNumberOfCells();
                //inner loop, loops through columns
                for (int c = 0; c < cellsCount; c++) {
                    //handles if there are to many columns on the excel sheet.
                    if (c > 3) {
                        Log.e(TAG, "readExcelData: ERROR. Excel File Format is incorrect! ");
                        toastMessage("ERROR: Excel File Format is incorrect!");
                        break;
                    } else {
                        String value = getCellAsString(row, c, formulaEvaluator);
                        String cellInfo = "r:" + r + "; c:" + c + "; v:" + value;
                        Log.d(TAG, "readExcelData: Data from row: " + cellInfo);
                        sb.append(value + ", ");
                    }
                }
                sb.append(":");
            }
            Log.d(TAG, "readExcelData: STRINGBUILDER: " + sb.toString());

            parseStringBuilder(sb);

        } catch (FileNotFoundException e) {
            Log.e(TAG, "readExcelData: FileNotFoundException. " + e.getMessage());
        } catch (IOException e) {
            Log.e(TAG, "readExcelData: Error reading inputstream. " + e.getMessage());
        }
    }

    /**
     * Method for parsing imported data and storing in ArrayList<XYValue>
     */
    public void parseStringBuilder(StringBuilder mStringBuilder) {
        Log.d(TAG, "parseStringBuilder: Started parsing.");

        // splits the sb into rows.
        String[] rows = mStringBuilder.toString().split(":");

        //Add to the ArrayList<XYValue> row by row
        for (int i = 0; i < rows.length; i++) {
            //Split the columns of the rows
            String[] columns = rows[i].split(",");

            //use try catch to make sure there are no "" that try to parse into doubles.
            try {
                String x = (columns[0]);
                double y = Double.parseDouble(columns[1]);
                double z = Double.parseDouble(columns[2]);

                String cellInfo = "(x,y,z): (" + x + "," + y + "," + z + ")";
                Log.d(TAG, "ParseStringBuilder: Data from row: " + cellInfo);

                //add the the uploadData ArrayList
                uploadData.add(new XYValue(x, y, z));

            } catch (NumberFormatException e) {

                Log.e(TAG, "parseStringBuilder: NumberFormatException: " + e.getMessage());

            }
        }

        printDataToLog();
    }

    private void printDataToLog() {
        Log.d(TAG, "printDataToLog: Printing data to log...");

        for (int i = 0; i < uploadData.size(); i++) {
            String x = uploadData.get(i).getX();
            double y = uploadData.get(i).getY();
            double z = uploadData.get(i).getZ();
            Log.d(TAG, "printDataToLog: (x,y,z): (" + x + "," + y + "," + z + ")");
        }
    }

    /**
     * Returns the cell as a string from the excel file
     *
     * @param row
     * @param c
     * @param formulaEvaluator
     * @return
     */
    private String getCellAsString(Row row, int c, FormulaEvaluator formulaEvaluator) {
        String value = "";
        try {
            Cell cell = row.getCell(c);
            CellValue cellValue = formulaEvaluator.evaluate(cell);
            switch (cellValue.getCellType()) {
                case Cell.CELL_TYPE_BOOLEAN:
                    value = "" + cellValue.getBooleanValue();
                    break;
                case Cell.CELL_TYPE_NUMERIC:
                    double numericValue = cellValue.getNumberValue();
                    if (HSSFDateUtil.isCellDateFormatted(cell)) {
                        double date = cellValue.getNumberValue();
                        SimpleDateFormat formatter =
                                new SimpleDateFormat("dd/MM/yy");
                        value = formatter.format(HSSFDateUtil.getJavaDate(date));
                    } else {
                        value = "" + numericValue;
                    }
                    break;
                case Cell.CELL_TYPE_STRING:
                    value = "" + cellValue.getStringValue();
                    break;
                default:
            }
        } catch (NullPointerException e) {

            Log.e(TAG, "getCellAsString: NullPointerException: " + e.getMessage());
        }
        return value;
    }

    private void checkInternalStorage() {
        ArrayList<File> excelSheet = readExcleFile(Environment.getExternalStorageDirectory());
        FileNameStrings = new String[excelSheet.size()];
        for (int i = 0; i < excelSheet.size(); i++) {
            FileNameStrings[i] = excelSheet.get(i).getName().toString().replace(".xlsx", " ");
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, FileNameStrings);

            lvInternalStorage.setAdapter(adapter);

        }


        //        Log.d(TAG, "checkInternalStorage: Started.");
//        try {
//            if (!Environment.getExternalStorageState().equals(
//                    Environment.MEDIA_MOUNTED)) {
//                toastMessage("No SD card found.");
//            } else {
//                // Locate the image folder in your SD Car;d
//                file = new File(pathHistory.get(count));
//
//                Log.d(TAG, "checkInternalStorage: directory path: " + pathHistory.get(count));
//            }
//
//            listFile = file.listFiles();
//
//            // Create a String array for FilePathStrings
//            FilePathStrings = new String[listFile.length];
//
//            // Create a String array for FileNameStrings
//            FileNameStrings = new String[listFile.length];
//
//            for (int i = 0; i < listFile.length; i++) {
//                if (listFile[i].getName().endsWith(".xlxs")){
//                    // Get the path of the image file
//                    FilePathStrings[i] = listFile[i].getAbsolutePath();
//                    // Get the name image file
//                    FileNameStrings[i] = listFile[i].getName();
//                }else if(listFile[i].isDirectory()){if (listFile[i].getName().endsWith(".xlxs")){
//                    // Get the path of the image file
//                    FilePathStrings[i] = listFile[i].getAbsolutePath();
//                    // Get the name image file
//                    FileNameStrings[i] = listFile[i].getName();
//                }}
//
//            }
//
//            for (int i = 0; i < listFile.length; i++) {
//                Log.d("Files", "FileName:" + listFile[i].getName());
//            }
//
//            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, FilePathStrings);
//            lvInternalStorage.setAdapter(adapter);
//
//        } catch (NullPointerException e) {
//            Log.e(TAG, "checkInternalStorage: NULLPOINTEREXCEPTION " + e.getMessage());
//        }
    }

    private void checkFilePermissions() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
            int permissionCheck = this.checkSelfPermission("Manifest.permission.READ_EXTERNAL_STORAGE");
            permissionCheck += this.checkSelfPermission("Manifest.permission.WRITE_EXTERNAL_STORAGE");
            if (permissionCheck != 0) {

                this.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 1001); //Any number
            }
        } else {
            Log.d(TAG, "checkBTPermissions: No need to check permissions. SDK version < LOLLIPOP.");
        }
    }

    /**
     * customizable toast
     *
     * @param message
     */
    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }


    public ArrayList<File> readExcleFile(File root) {
        ArrayList<File> arrayList = new ArrayList<File>();
        File file3[] = root.listFiles();
        for (File files : file3) {
            if (files.isDirectory()) {
                arrayList.addAll(readExcleFile(files));
            } else {
                if (files.getName().endsWith(".xlsx")) {
                    arrayList.add(files);
                }
            }
        }
        return arrayList;
    }

}


//public void findEceleInFolder(File folder){
//        if(folder.listFiles().length > 0){
//            for(File file:folder.listFiles()){
//                Log.e("test",file.getPath());
//                if(file.isDirectory()){
//                    findEceleInFolder(file);
//                }
//                else if(file.getName().endsWith(".xlxs")){
//                    Log.e("textn",file.getPath());
//                    HashMap<String,String> fileEx = new HashMap<String,String>();
//                    fileEx.put("nameFile",file.getName().substring(0,(file.getName().length() - 4)));
//                    fileEx.put("filePhth",file.getPath());
//                    FilePathStrings1.add(fileEx);
//                }
//            }
//        }
//}

//https://www.youtube.com/watch?v=Yqvekq3IHa8
//https://github.com/mitchtabian/ImportFromExcel/blob/master/ImportExcelData/app/src/main/java/com/tabian/importexceldata/MainActivity.java