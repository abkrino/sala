package pharamacy.eg.sala;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SearchProduct extends AppCompatActivity {
    String local_medicines, imported_medicines, accessories, userId;
    private FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_product);
        local_medicines = getIntent().getStringExtra("local_medicine");
        imported_medicines = getIntent().getStringExtra("imported_medicines");
        accessories = getIntent().getStringExtra("accessories");
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("product");
        if (local_medicines != null) {
            reference.child(local_medicines).getDatabase();
        } else if (imported_medicines != null) {
            reference.child(imported_medicines);
        }else if (accessories != null) {
            reference.child(accessories);
        }
    }
}