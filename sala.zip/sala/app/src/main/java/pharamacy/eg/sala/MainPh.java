package pharamacy.eg.sala;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainPh extends AppCompatActivity {
    Button local_medicines, imported_medicines, accessories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_ph);
        local_medicines = findViewById(R.id.Local_medicines);
        imported_medicines = findViewById(R.id.Imported_medicines);
        accessories = findViewById(R.id.Accessories);
    }

    public void goSearchLocal_medicines(View view) {
        Intent intent = new Intent(MainPh.this,SearchProduct.class);
        intent.putExtra("local_medicines",local_medicines.getText());
        startActivity(intent);
    }

    public void goSearchImported_medicines(View view) {
        Intent intent = new Intent(MainPh.this,SearchProduct.class);
        intent.putExtra("Imported_medicines",imported_medicines.getText());
        startActivity(intent);
    }

    public void goSearchAccessories(View view) {
        Intent intent = new Intent(MainPh.this,SearchProduct.class);
        intent.putExtra("Accessories",accessories.getText());
        startActivity(intent);
    }
}
