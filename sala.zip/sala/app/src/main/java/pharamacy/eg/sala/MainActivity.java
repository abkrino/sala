package pharamacy.eg.sala;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.Button;
import android.widget.EditText;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import pharamacy.eg.sala.Class.GlideApp;
import pharamacy.eg.sala.Class.Product;
import pharamacy.eg.sala.Class.MainAdapter;
import yogesh.firzen.filelister.FileListerDialog;
import yogesh.firzen.filelister.OnFileSelectedListener;
public class MainActivity extends AppCompatActivity {
    String userId,Specia_workU;
    private StorageReference mStorage;
    private FirebaseUser user;
    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference;
    public ArrayList<Product> list =  new ArrayList<Product>();
    private static final String TAG = "MainActivity";
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser== null) {
            startActivity(new Intent(MainActivity.this, SignIN.class));
            finish();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
            DrawerLayout drawer = findViewById(R.id.drawer_layout);
            NavigationView navigationView = findViewById(R.id.nav_view);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                    this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawer.addDrawerListener(toggle);
            toggle.syncState();
            View header = navigationView.getHeaderView(0);
            ImageView imageView = header.findViewById(R.id.nav_img);
            ConstraintLayout sign_out_btn = header.findViewById(R.id.signOut);
            ConstraintLayout profile_btn = header.findViewById(R.id.profile_btn);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        user = FirebaseAuth.getInstance().getCurrentUser();
        userId = user.getPhoneNumber();
            ///////////////////////////////////////////////////////////////////////////////////////////
        SharedPreferences sharedPref = this.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        String excelPath = sharedPref.getString("excelpath" , null) ;
        if(excelPath != null){
            readExcelData(excelPath);
            RecyclerView recycle = findViewById(R.id.recycle_main);
            final MainAdapter adapter = new MainAdapter(getApplicationContext() , list);
            recycle.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            recycle.setAdapter(adapter);
        }
        DatabaseReference reference = FirebaseDatabase.getInstance().
                getReference().child("users").child("Offices").child(userId);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Specia_workU = dataSnapshot.child("Specia_work").getValue().toString();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        profile_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Profile.class));
                drawer.closeDrawer(GravityCompat.START);

            }
        });
        ////////////////////////////////////////////////////////////////////////////////////////////
        FileListerDialog fileListerDialog = FileListerDialog.createFileListerDialog(this , R.style.AppTheme);
        fileListerDialog.setDefaultDir("/storage/emulated/0");
        fileListerDialog.setFileFilter(FileListerDialog.FILE_FILTER.ALL_FILES);
        fileListerDialog.setOnFileSelectedListener(new OnFileSelectedListener() {

            @Override
            public void onFileSelected(File file, String path) {
                list.clear();
                readExcelData(path);
                RecyclerView recycle = findViewById(R.id.recycle_main);
                MainAdapter adapter = new MainAdapter(getApplicationContext() , list);
                adapter.updateList(list);
                list.size();
                recycle.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                recycle.setAdapter(adapter);
                editor.putString("excelpath" , path);
                editor.apply();
                ///////////////////////////////////////////////////////////////////////////////////////////
                //upload date product to fire base
                for (int p = 1; p < list.size() ; p++) {
                    databaseReference.child("product");
                    int finalP = p;
                    databaseReference.addChildEventListener(new ChildEventListener() {
                        @Override
                        public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                       writeNewPost( userId, list.get(finalP ).getName(),  list.get(finalP).getPrice(), list.get(finalP).getDiscount());
                        }
                        @Override
                        public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
//                            writeNewPost( userId, list.get(finalP ).getName(),  list.get(finalP).getPrice(), list.get(finalP).getDiscount());

                        }
                        @Override
                        public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                        }

                        @Override
                        public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
                        }
                    });

                /////////////////////////////////////////////////////////////////////////////////////
        Button btn = findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void
            onClick(View v) {    alert( fileListerDialog);    } });
        final EditText search = findViewById(R.id.search_txt);
        ImageView cancel = findViewById(R.id.cancelbtn);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String a = s.toString();
                if(!a.isEmpty())  {cancel.setVisibility(View.VISIBLE); }
                if(a.isEmpty())  {cancel.setVisibility(View.INVISIBLE); }
                RecyclerView recycle = findViewById(R.id.recycle_main);
                MainAdapter adapter = new MainAdapter(getApplicationContext() , list);
                recycle.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                adapter.getFilter().filter(s);
                recycle.setAdapter(adapter);
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search.setText("");
            }
        });
        mAuth = FirebaseAuth.getInstance();
        ///////////////////////////////////////////////////////////////////////////////////////////
            profile_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(MainActivity.this, Profile.class));
                    drawer.closeDrawer(GravityCompat.START);
                }
            });
            ////////////////////////////////////////////////////////////////////////////////////////////
            if (mStorage != null) {
                mStorage.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        // Got the download URL for 'users/me/profile.png'
                        GlideApp.with(MainActivity.this)
                                .load(uri)
                                .into(imageView);
                   }

               }).addOnFailureListener(new OnFailureListener() {
                   @Override
                   public void onFailure(@NonNull Exception exception) {
                       // Handle any errors
                   }
               });
           }
            sign_out_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mAuth.signOut();
                    startActivity(new Intent(MainActivity.this, SignIN.class));
                    finish();
                }
            });
            ////////////////////////////////////////////////////////////////////////////////////////////////
        }
    public void alert(FileListerDialog fileListerDialog) {
        LayoutInflater factory = LayoutInflater.from(this);
        if (Specia_workU.equals("أدوية")) {
            final View deleteDialogView = factory.inflate(R.layout.alert_view, null);
            final AlertDialog deleteDialog = new AlertDialog.Builder(this).create();
            deleteDialog.setView(deleteDialogView);
            deleteDialogView.findViewById(R.id.alert_btn).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //your business logic
                    deleteDialog.dismiss();
                    fileListerDialog.show();
                }
            });
            deleteDialog.show();
        }else{final View deleteDialogView = factory.inflate(R.layout.alert_view2, null);
            final AlertDialog deleteDialog = new AlertDialog.Builder(this).create();
            deleteDialog.setView(deleteDialogView);
            deleteDialogView.findViewById(R.id.alert_btn).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //your business logic
                    deleteDialog.dismiss();
                    fileListerDialog.show();
                }
            });
            deleteDialog.show();}
    }
    @Override
        public void onBackPressed () {
            DrawerLayout drawer = findViewById(R.id.drawer_layout);
            if (drawer.isDrawerOpen(GravityCompat.START)) {
                drawer.closeDrawer(GravityCompat.START);
            } else {
                super.onBackPressed();
            }
        }
    private void readExcelData(String filePath) {
        //declare input file
        File inputFile = new File(filePath);
        try {
            InputStream inputStream = new FileInputStream(inputFile);
            XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
            XSSFSheet sheet = workbook.getSheetAt(0);
            int rowsCount = sheet.getPhysicalNumberOfRows();
            FormulaEvaluator formulaEvaluator = workbook.getCreationHelper().createFormulaEvaluator();
            //outer loop, loops through rows
            for (int r = 0; r < rowsCount; r++) {
                Row row = sheet.getRow(r);
                int cellsCount = row.getPhysicalNumberOfCells();
                String a = null , b = null , d = null;
                //inner loop, loops through columns
                for (int i = 0; i < cellsCount; i++) {
                    //handles if there are to many columns on the excel sheet.
                    if (i > 2) {
                        Log.e(TAG, "readExcelData: ERROR. Excel File Format is incorrect! ");
                        break;
                    } else {
                        String value = getCellAsString(row, i, formulaEvaluator);
                        String cellInfo = "r:" + r + "; c:" + i + "; v:" + value;
                        Log.d(TAG, "readExcelData: Data from row: " + cellInfo);
                        switch(i) {
                            case 0 : a = value;
                            break;
                            case 1 : b = value;
                            break;
                            case 2 : d = value;
                           list.add(new Product( a , b , d));
                            break;
                        }
                    }
                }
            }
            Log.d(TAG, "readExcelData: STRINGBUILDER: " + list.size());
        } catch (FileNotFoundException e) {
            Log.e(TAG, "readExcelData: FileNotFoundException. " + e.getMessage());
        } catch (IOException e) {
            Log.e(TAG, "readExcelData: Error reading inputstream. " + e.getMessage());
        }
    }
    private String getCellAsString(Row row, int c, FormulaEvaluator formulaEvaluator) {
        String value = "";
        try {
            Cell cell = row.getCell(c);
            CellValue cellValue = formulaEvaluator.evaluate(cell);
            switch (cellValue.getCellType()) {
                case Cell.CELL_TYPE_BOOLEAN:
                    value = "" + cellValue.getBooleanValue();
                    break;
                case Cell.CELL_TYPE_NUMERIC:
                    double numericValue = cellValue.getNumberValue();
                    if (HSSFDateUtil.isCellDateFormatted(cell)) {
                        double date = cellValue.getNumberValue();
                        SimpleDateFormat formatter =
                                new SimpleDateFormat("dd/MM/yy" , Locale.US);
                        value = formatter.format(HSSFDateUtil.getJavaDate(date));
                    } else {
                        value = "" + numericValue;
                    }
                    break;
                case Cell.CELL_TYPE_STRING:
                    value = "" + cellValue.getStringValue();
                    break;
                default:
            }
        } catch (NullPointerException e) {

            Log.e(TAG, "getCellAsString: NullPointerException: " + e.getMessage());
        }
        return value;
    }
        private void writeNewPost (String userId, String nameProduct, String price, String discount )
        {
            // Create new post at /user-posts/$userid/$postid and at
            // /posts/$postid simultaneously
             // attention firebase don't support ( '.', '#' ,'$' ,'[',' ]')
            if (nameProduct.contains(".")){ nameProduct = nameProduct.replace('.', ',');
            }else if (nameProduct.contains("#")){nameProduct =nameProduct.replace('#','\t');
            }else if (nameProduct.contains("$")){nameProduct =nameProduct.replace('$','\t');
            }else if (nameProduct.contains("[")){nameProduct =nameProduct.replace('[','\t');
            }else if (nameProduct.contains("]")){nameProduct =nameProduct.replace(']','\t');
            }else if (nameProduct.contains("/")){nameProduct =nameProduct.replace('/','\\');}
            Product product = new Product(price, discount);
            Map<String, Object> productValues = product.toMap();
            databaseReference.child("product").child(Specia_workU).child(nameProduct).child(userId);
            Map<String, Object> childUpdates = new HashMap<>();
            childUpdates.put("/product/" + "/" + Specia_workU + "/" + "/" + nameProduct + "/" +"/" + userId + "/", productValues);
            databaseReference.updateChildren(childUpdates);
        }
}






