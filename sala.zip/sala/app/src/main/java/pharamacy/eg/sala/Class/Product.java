package pharamacy.eg.sala.Class;

import com.google.firebase.database.Exclude;

import java.util.HashMap;
import java.util.Map;

public class Product {
    String name;
    String price;
    String discount;

    public Product() {
    }

    public Product(String name) {
        this.name = name;
    }

    public Product(String price, String discount) {
        this.price = price;
        this.discount = discount;
    }

    public Product(String name, String price, String discount) {
        this.name = name;
        this.price = price;
        this.discount = discount;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }

    public String getDiscount() {
        return discount;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }
    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("nameProduct", name);
        result.put("price", price);
        result.put("discount", discount);


        return result;
    }
}
