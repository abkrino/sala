package pharamacy.eg.sala.Class;

import android.content.Context;
import android.media.MediaPlayer;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;

import pharamacy.eg.sala.R;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder> implements Filterable {

    LayoutInflater mInflater;
    Context context;
    ItemClickListener mClickListener;
    ArrayList<Product> list;
    ArrayList<Product> prouductListFiltered = new ArrayList<>();
    // data is passed into the constructor
    public MainAdapter(Context context , ArrayList<Product> list ) {
        this.context = context;
        this.mInflater = LayoutInflater.from(context);
        this.list = list;
    }

    // inflates the row layout from xml when needed
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.main_cell, parent, false);
        return new ViewHolder(view);
    }

    // binds the data to the TextView in each row
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.name.setText(list.get(position).getName());
        holder.price.setText(list.get(position).getPrice());
        holder.discount.setText(list.get(position).getDiscount());
    }

    // total number of cells
    @Override
    public int getItemCount() {
        return list.size();
    }


    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView name;
        TextView price;
        TextView discount;


        ViewHolder(View itemView) {
            super(itemView);
            name  = itemView.findViewById(R.id.nameC);
            price = itemView.findViewById(R.id.priceC);
            discount = itemView.findViewById(R.id.discountC);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                }
            });
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }
    }

    // convenience method for getting data at click position
    int getItem(int position) {
        return position;
    }

    // allows clicks events to be caught
    void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    // parent activity will implement this method to respond to click events
    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    prouductListFiltered = list;
                } else {
                    ArrayList<Product> filteredList = new ArrayList<>();
                    for (Product product : list) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (product.getName().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(product);
                        }
                    }

                    prouductListFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = prouductListFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                prouductListFiltered = (ArrayList<Product>) filterResults.values;
                list = prouductListFiltered;
                // refresh the list with filtered data
                notifyDataSetChanged();
            }
        };
    }

    public void updateList(ArrayList<Product> list) {
        notifyDataSetChanged();
    }

}
